// OpenAI SVG Logo

const OpenAISVGLogo = () => (
  <div class="w-1">
    <div style={{ width: "50px", height: "50px" }}>
      <img
        src="https://i.imgur.com/EGGQJFm.jpg"
        style={{ width: "100%", height: "100%", borderRadius: "50%" }}
      ></img>
    </div>
  </div>
);

export default OpenAISVGLogo;
